/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Organization.Organization.Type;
import java.util.ArrayList;

/**
 *
 * @author raunak
 */
public class OrganizationDirectory {
    
    private ArrayList<Organization> organizationList;

    public OrganizationDirectory() {
        organizationList = new ArrayList<>();
    }

    public ArrayList<Organization> getOrganizationList() {
        return organizationList;
    }
    
    public Organization createOrganization(Type type){
        Organization organization = null;
        if (type.getValue().equals(Type.Doctor.getValue())){
            organization = new DoctorOrganization();
            organizationList.add(organization);
        }
        
        else if (type.getValue().equals(Type.Patient.getValue())){
            organization = new PatientOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.InsuranceAgent.getValue())){
            organization = new InsuranceAgentOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.PharmaceuticalCompanyAgent.getValue())){
            organization = new PharmaceuticalCompanyOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.PharmaceuticalSupplierAgent.getValue())){
            organization = new PharmaceuticalSupplierOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.Nurse.getValue())){
            organization = new NurseOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.DoctorFeedBack.getValue())){
            organization = new DoctorFeedBackOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.EnterpriseFeedBack.getValue())){
            organization = new EnterpriseFeedBackOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.DoctorFeedBack.getValue())){
            organization = new DoctorFeedBackOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.MedicalAdvisory.getValue())){
            organization = new MedicalAdvisoryOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.QuestionAndAnswer.getValue())){
            organization = new QuestionAndAnswerOrganization();
            organizationList.add(organization);
        }
        return organization;
    }
}