/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

/**
 *
 * @author Gowtham
 */
public class DoctorFeedBackWorkRequest extends WorkRequest {

    private String doctorname;
    private String doctorEnterprise;
    private String doctorFeedBackComments;
    private String doctorProblem;

    public String getDoctorname() {
        return doctorname;
    }

    public void setDoctorname(String doctorname) {
        this.doctorname = doctorname;
    }

    public String getDoctorEnterprise() {
        return doctorEnterprise;
    }

    public void setDoctorEnterprise(String doctorEnterprise) {
        this.doctorEnterprise = doctorEnterprise;
    }

    public String getDoctorFeedBackComments() {
        return doctorFeedBackComments;
    }

    public void setDoctorFeedBackComments(String doctorFeedBackComments) {
        this.doctorFeedBackComments = doctorFeedBackComments;
    }

    public String getDoctorProblem() {
        return doctorProblem;
    }

    public void setDoctorProblem(String doctorProblem) {
        this.doctorProblem = doctorProblem;
    }

    @Override
    public String toString() {
        return this.doctorname;
    }

}
