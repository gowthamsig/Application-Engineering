/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

/**
 *
 * @author Gowtham
 */
public class EnterpriseFeedBackWorkRequest extends WorkRequest {

    private String enterprise;
    private String enteprisePatient;
    private String enterprisefeedBack;
    private String enterprisecomments;
    private String commentedby;
    
   
    
    public String getEnterprise() {
        return enterprise;
    }

    public void setEnterprise(String enterprise) {
        this.enterprise = enterprise;
    }

    public String getEnterprisefeedBack() {
        return enterprisefeedBack;
    }

    public void setEnterprisefeedBack(String enterprisefeedBack) {
        this.enterprisefeedBack = enterprisefeedBack;
    }

    public String getEnterprisecomments() {
        return enterprisecomments;
    }

    public void setEnterprisecomments(String enterprisecomments) {
        this.enterprisecomments = enterprisecomments;
    }

       public String getEnteprisePatient() {
        return enteprisePatient;
    }

    public void setEnteprisePatient(String enteprisePatient) {
        this.enteprisePatient = enteprisePatient;
    }

    public String getCommentedby() {
        return commentedby;
    }

    public void setCommentedby(String commentedby) {
        this.commentedby = commentedby;
    }
    

    @Override
    public String toString() {
        return this.enterprise;
    }

}
