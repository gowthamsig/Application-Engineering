/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.WorkQueue;

/**
 *
 * @author Gowtham
 */
public class DrugFeedBackWorkRequest extends WorkRequest {
    
    private String drug;
    private String drugCompany;
    private String symptoms;
    private String feedBack;

    public String getDrug() {
        return drug;
    }

    public void setDrug(String drug) {
        this.drug = drug;
    }

    public String getDrugCompany() {
        return drugCompany;
    }

    public void setDrugCompany(String drugCompany) {
        this.drugCompany = drugCompany;
    }

    public String getSymptoms() {
        return symptoms;
    }

    public void setSymptoms(String symptoms) {
        this.symptoms = symptoms;
    }

    public String getFeedBack() {
        return feedBack;
    }

    public void setFeedBack(String feedBack) {
        this.feedBack = feedBack;
    }

   

    @Override
    public String toString() {
        return this.drug;
    }
     
    
    
}
