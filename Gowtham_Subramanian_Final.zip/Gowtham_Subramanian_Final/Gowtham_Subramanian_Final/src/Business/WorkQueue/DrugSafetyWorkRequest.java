/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.WorkQueue;

/**
 *
 * @author Gowtham
 */
public class DrugSafetyWorkRequest extends WorkRequest{
    
    private String drugName;
    private String drugSafetyMessage;
    private String drugImpact;

    public String getDrugName() {
        return drugName;
    }

    public void setDrugName(String drugName) {
        this.drugName = drugName;
    }

    public String getDrugSafetyMessage() {
        return drugSafetyMessage;
    }

    public void setDrugSafetyMessage(String drugSafetyMessage) {
        this.drugSafetyMessage = drugSafetyMessage;
    }

    public String getDrugImpact() {
        return drugImpact;
    }

    public void setDrugImpact(String drugImpact) {
        this.drugImpact = drugImpact;
    }
    
    }
