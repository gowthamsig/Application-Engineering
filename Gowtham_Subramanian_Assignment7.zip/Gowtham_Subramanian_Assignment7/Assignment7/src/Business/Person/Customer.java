/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Person;

import Business.Order.Order;
import java.util.Date;

/**
 *
 * @author gowtham
 */
public class Customer extends Person {
    private static int customerCount = 2000;
    private int customerID;
    private Order order;
    private String occupation;
    Date dateOfBirth;
    //private MasterOrderCatalog customerOrderCatalog;

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }
    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    /*public MasterOrderCatalog getCustomerOrderCatalog() {
        return customerOrderCatalog;
    }

    public void setCustomerOrderCatalog(MasterOrderCatalog customerOrderCatalog) {
        this.customerOrderCatalog = customerOrderCatalog;
    }*/

    
    public Customer()
    {
        customerCount++;
        customerID = customerCount;
        order = new Order();
        //customerOrderCatalog = new MasterOrderCatalog();
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    

    @Override
    public String toString() {
        return firstName+" "+lastName;
    }
    
    
}
