/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Person;

import Business.Product.ProductCatalog;

/**
 *
 * @author gowtham
 */
public class Supplier extends Person {
    
    private static int supplierCount = 3000;
    private int supplierID;
    private ProductCatalog productCatalog;
    private String organization;

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }
    
    public Supplier() {
        supplierCount++;
        supplierID = supplierCount;
        productCatalog = new ProductCatalog();
    }

    public ProductCatalog getProductCatalog() {
        return productCatalog;
    }

    public void setProductCatalog(ProductCatalog productCatalog) {
        this.productCatalog = productCatalog;
    }
    
    @Override
    public String toString() {
        return firstName+" "+lastName;
    }
    
}
