/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Person;

import java.util.Date;

/**
 *
 * @author gowtham
 */
public class Person {
    static int count = 1000;
   int personId;
   String firstName;
   String lastName;
   
   String emailId;

    

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }
   
   
   public Person()
   {
       count++;
       personId = count;
   }

    public int getPersonId() {
        return personId;
    }

    public void setPersonId(int personId) {
        this.personId = personId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    @Override
    public String toString() {
        return lastName+", "+firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
}
