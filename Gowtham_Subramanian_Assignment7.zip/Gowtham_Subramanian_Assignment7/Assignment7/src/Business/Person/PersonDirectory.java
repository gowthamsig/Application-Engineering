/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Person;

import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author gowtham
 */
public class PersonDirectory {
    
    private ArrayList<Person> personDirectory;

    public PersonDirectory() {
        personDirectory = new ArrayList<Person>();
    }

    public ArrayList<Person> getPersonDirectory() {
        return personDirectory;
    }

    public void setPersonDirectory(ArrayList<Person> personDirectory) {
        this.personDirectory = personDirectory;
    }
    public Customer createCustomer()
    {
        Customer customer = new Customer();
        personDirectory.add(customer);
        return customer;
    }
    public Supplier createSupplier()
    {
        Supplier Supplier = new Supplier();
        personDirectory.add(Supplier);
        return Supplier;
    }
    public void deletePerson(Person person)
    {
        personDirectory.remove(person);
    }
}
