/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Person.Person;
import Business.Person.PersonDirectory;
import Business.Role.Role;
import Business.UserAccount.UserAccountDirectory;
import java.util.ArrayList;

/**
 *
 * @author gowtham
 */
public abstract class Organization {
    public enum OrganizationType
    {
        Admin("Admin Organization")
        ,Supplier("Supplier Organization")
        ,Customer("Customer Organization");
        
        private String value;
        private OrganizationType(String value)
        {
        this.value = value;
        }
        
        public String getValue()
        {
            return value;
        }

        @Override
        public String toString() {
            return this.getClass().getName();
        }
    }
    
    private String organizationName;
    private UserAccountDirectory userAccountDirectory;
    private PersonDirectory personDirectory;

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public UserAccountDirectory getUserAccountDirectory() {
        return userAccountDirectory;
    }

    public void setUserAccountDirectory(UserAccountDirectory userAccountDirectory) {
        this.userAccountDirectory = userAccountDirectory;
    }

    public PersonDirectory getPersonDirectory() {
        return personDirectory;
    }

    public void setPersonDirectory(PersonDirectory personDirectory) {
        this.personDirectory = personDirectory;
    }

    public Organization(String organizationType) {
        this.organizationName = organizationType;
        userAccountDirectory = new UserAccountDirectory();
        personDirectory = new PersonDirectory();
        
    }
    public abstract ArrayList<Role> getSupportedRoles();  
}
