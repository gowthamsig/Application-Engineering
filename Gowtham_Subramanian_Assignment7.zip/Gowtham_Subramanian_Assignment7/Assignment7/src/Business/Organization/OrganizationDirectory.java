/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import java.util.ArrayList;

/**
 *
 * @author gowtham
 */
public class OrganizationDirectory {
    private ArrayList<Organization> organizationDirectory;

    public OrganizationDirectory() {
        organizationDirectory = new ArrayList<Organization>();
    }

    public ArrayList<Organization> getOrganizationDirectory() {
        return organizationDirectory;
    }

    public void setOrganizationDirectory(ArrayList<Organization> organizationDirectory) {
        this.organizationDirectory = organizationDirectory;
    }

    
    public Organization createOrganization(Organization.OrganizationType organizationType)
    {
        Organization organization;
        if(organizationType.equals(Organization.OrganizationType.Customer))
        {
            organization = new CustomerOrganization();
            organizationDirectory.add(organization);
            return organization;
        }
        else if(organizationType.equals(Organization.OrganizationType.Supplier))
        {
            organization = new SupplierOrganization();
            organizationDirectory.add(organization);
            return organization;
        }
        return null;
    }
    public Organization getOrganization(Organization.OrganizationType organizationType)
    {
        for(Organization organization:organizationDirectory)
        {
            if(organization.getOrganizationName().equals(organizationType.getValue()))
            {
                return organization;
            }
        }
        return null;
    }
    
    
}
