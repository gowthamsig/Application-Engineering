/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Order;

import Business.Person.Supplier;
import Business.Person.Customer;
import Business.Product.Product;
import Business.Order.Order;
import Business.Order.OrderItem;
import java.util.ArrayList;

/**
 *
 * @author gowtham
 */
public class MasterOrderCatalog {
    private ArrayList<Order> orderCatalog;
    public MasterOrderCatalog getOrderForCustomer(Customer customer)
    {
        MasterOrderCatalog customerCatalog = new MasterOrderCatalog();
        for(Order order:orderCatalog)
        {
            if(order.getCustomer().equals(customer))
            {
                customerCatalog.addOrder(order);
            }
        }
        return customerCatalog;
    }
    
    public MasterOrderCatalog()
    {
        orderCatalog = new ArrayList<Order>();
    }

    public ArrayList<Order> getOrderCatalog() {
        return orderCatalog;
    }

    public void setOrderCatalog(ArrayList<Order> orderCatalog) {
        this.orderCatalog = orderCatalog;
    }
    
    public Order addOrder(Order order)
    {
        orderCatalog.add(order);
        return order;
    }
    
    public ArrayList<OrderItem> getSupplierOrder(Supplier supplier)
    {
        ArrayList<OrderItem> supplierOrder = new ArrayList<OrderItem>();
        for(Product product:supplier.getProductCatalog().getProductCatalog())
        {
            for(Order order:orderCatalog)
            {
                for(OrderItem orderItem:order.getOrderItemList())
                {
                    if(orderItem.getProduct().getModelNumber()==product.getModelNumber())
                    {
                        supplierOrder.add(orderItem);
                    }
                }
            }
        }
        return supplierOrder;
    }
    public ArrayList<OrderItem> getProductOrder(Product product)
    {
        ArrayList<OrderItem> supplierOrder = new ArrayList<OrderItem>();
        
            for(Order order:orderCatalog)
            {
                for(OrderItem orderItem:order.getOrderItemList())
                {
                    if(orderItem.getProduct().getModelNumber()==product.getModelNumber())
                    {
                        supplierOrder.add(orderItem);
                    }
                }
            }
        
        return supplierOrder;
    }
    
}
