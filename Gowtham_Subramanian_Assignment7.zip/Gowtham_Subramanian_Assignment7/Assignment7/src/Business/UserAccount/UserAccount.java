/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.UserAccount;

import Business.Person.Person;
import Business.Role.Role;

/**
 *
 * @author gowtham
 */
public class UserAccount {
    
    static int userCount = 4000;
    private String userName;
    private String password;
    private Role role;
    private boolean isActive;
    private int userID;

    public Person getPerson() {
        return person;
    }

    @Override
    public String toString() {
        return person.toString();
    }

    public void setPerson(Person person) {
        this.person = person;
    }
    private Person person;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    

    public boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(boolean isActive) {
        this.isActive = isActive;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }
    
    public UserAccount()
    {
        userCount++;
        userID = userCount;
    }
    
}
