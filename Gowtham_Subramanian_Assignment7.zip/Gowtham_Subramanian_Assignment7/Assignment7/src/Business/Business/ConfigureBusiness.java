/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Business;

import Business.Organization.AdminOrganization;
import Business.Organization.Organization.OrganizationType;
import Business.Person.Person;
import Business.Role.AdminRole;
import Business.UserAccount.UserAccount;

/**
 *
 * @author gowtham
 */
public class ConfigureBusiness {
    public static Business initialize()
    {
        Business business = Business.getInstance();
        AdminOrganization adminOrganization = new AdminOrganization();
        business.getOrganizationDirectory().getOrganizationDirectory().add(adminOrganization);
        Person person = new Person();
        person.setFirstName("Admin");
        person.setLastName("Admin");
        adminOrganization.getPersonDirectory().getPersonDirectory().add(person);
        UserAccount userAccount = adminOrganization.getUserAccountDirectory().createAndAddUserAccount();
        userAccount.setUserName("admin");
        userAccount.setPassword("admin");
        userAccount.setPerson(person);
        userAccount.setRole(new AdminRole());
        userAccount.setIsActive(true);
        business.getOrganizationDirectory().createOrganization(OrganizationType.Customer);
        business.getOrganizationDirectory().createOrganization(OrganizationType.Supplier);
        return business;
    }
    
}
