/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Business;


import Business.Order.MasterOrderCatalog;
import Business.Organization.OrganizationDirectory;


/**
 *
 * @author gowtham
 */
public class Business {
    private MasterOrderCatalog masterOrderCatalog;
    private OrganizationDirectory organizationDirectory;

    
    private static Business business;

    private Business()
    {
        masterOrderCatalog = new MasterOrderCatalog();
        organizationDirectory = new OrganizationDirectory();
    }
    public static Business getInstance()
    {
        if(business == null)
        {
            business = new Business();
        }
        return business;
    }

    public MasterOrderCatalog getMasterOrderCatalog() {
        return masterOrderCatalog;
    }

    public void setMasterOrderCatalog(MasterOrderCatalog masterOrderCatalog) {
        this.masterOrderCatalog = masterOrderCatalog;
    }

    public OrganizationDirectory getOrganizationDirectory() {
        return organizationDirectory;
    }

    public void setOrganizationDirectory(OrganizationDirectory organizationDirectory) {
        this.organizationDirectory = organizationDirectory;
    }

    

}
