/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessLogic;

/**
 *
 * @author Gowtham
 */
public class PatientVitalSign {

    private float respiratoryRate;
    private float heartRate;
    private float systolicBloodPressure;
    private float weight;
    private String date;
    private String vitalSignStatus;

    public String getVitalSignStatus() {
        return vitalSignStatus;
    }

    public void setVitalSignStatus(String vitalSignStatus) {
        this.vitalSignStatus = vitalSignStatus;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    

   

    public PatientVitalSign() {
    }

    public float getRespiratoryRate() {
        return respiratoryRate;
    }

    public void setRespiratoryRate(float respiratoryRate) {
        this.respiratoryRate = respiratoryRate;
    }

    public float getHeartRate() {
        return heartRate;
    }

    public void setHeartRate(float heartRate) {
        this.heartRate = heartRate;
    }

    public float getSystolicBloodPressure() {
        return systolicBloodPressure;
    }

    public void setSystolicBloodPressure(float systolicBloodPressure) {
        this.systolicBloodPressure = systolicBloodPressure;
    }

    public float getWeight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }

    @Override
    public String toString() {
        return String.valueOf(this.date);
    }

           

    public void calculation(int age, float respiratoryRate, float heartRate, float systolicBloodPressure, float weight) {

        setVitalSignStatus("Abnormal");

        if (age >= 1 && age <= 3) {
            if (respiratoryRate >= 20 && respiratoryRate <= 30) {
                if (heartRate >= 80 && heartRate <= 130) {
                    if (systolicBloodPressure >= 80 && systolicBloodPressure <= 110) {
                        if (weight >= 22 && weight < 31) {

                            setVitalSignStatus("Normal");
                        }
                    }
                }
            }
        } else if (age >= 4 && age <= 5) {

            if (respiratoryRate >= 20 && respiratoryRate <= 30) {
                if (heartRate >= 80 && heartRate <= 120) {
                    if (systolicBloodPressure >= 80 && systolicBloodPressure <= 110) {
                        if (weight >= 31 && weight <= 40) {
                            setVitalSignStatus("Normal");
                        }
                    }
                }
            }
        } else if (age >= 6 && age <= 12) {
            if (respiratoryRate >= 20 && respiratoryRate <= 30) {
                if (heartRate >= 70 && heartRate <= 110) {
                    if (systolicBloodPressure >= 80 && systolicBloodPressure <= 120) {
                        if (weight >= 41 && weight <= 92) {

                            setVitalSignStatus("Normal");
                        }
                    }
                }
            }
        } else if (age >= 13) {
            if (respiratoryRate >= 12 && respiratoryRate <= 20) {
                if (heartRate >= 55 && heartRate <= 105) {
                    if (systolicBloodPressure >= 110 && systolicBloodPressure <= 120) {
                        if (weight >= 110) {
                            setVitalSignStatus("Normal");
                        }
                    }
                }
            }
        }
    }
}
