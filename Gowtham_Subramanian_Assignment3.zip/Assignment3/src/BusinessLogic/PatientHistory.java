/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package BusinessLogic;

import java.util.ArrayList;

/**
 *
 * @author Gowtham
 */
public class PatientHistory {
    
    
    private ArrayList<Patient> patientHistory;
    public PatientHistory(){
        
        patientHistory=new ArrayList<>();
        
    }

    public ArrayList<Patient> getPatientHistory() {
        return patientHistory;
    }

    public void setPatientHistory(ArrayList<Patient> patientHistory) {
        this.patientHistory = patientHistory;
    }
    public Patient addPatientHistory() {
        Patient patient = new Patient();
        patientHistory.add(patient);
        return patient;
    }

    public void removePatientHistory(Patient patient) {
        patientHistory.remove(patient);
    }
    
     public Patient searchPatinet(String patientID){
        for(Patient patient : patientHistory){
            if(patient.getPatientID().equals(patientID)){
                return patient;
        }
    }
    return null;
}
}
