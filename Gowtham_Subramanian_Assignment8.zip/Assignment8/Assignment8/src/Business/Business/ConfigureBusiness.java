/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Business;

import Business.Product.ProductDirectory;
import Business.Person.Person;
import Business.Person.Customer;
import Business.Person.Supplier;
import Business.UserAccount.UserAccount;
import Business.Organization.AdminOrganization;
import Business.Organization.CustomerOrganization;
import Business.Organization.SalesOrganization;
import Business.Organization.ShippingOrganization;
import Business.Organization.SupplierOrganization;
import Business.Role.AdminRole;
import Business.Role.CustomerRole;
import Business.Role.Role;
import Business.Role.SalesRole;
import Business.Role.ShippingRole;
import Business.Role.SupplierRole;

/**
 *
 * @author Gowtham
 */
public class ConfigureBusiness {
    public static Business initializeBusiness(){
        Business business = Business.getInstance();
        AdminOrganization adminOrganization = new AdminOrganization();
        business.getOrganizationDirectory().getOrganizationList().add(adminOrganization);
        
        Person person = new Person();
        person.setFirstName("Gowtham");
        person.setLastName("S");
        UserAccount userAccount = new UserAccount();
        userAccount.setUserName("admin");
        userAccount.setPassword("admin");
        userAccount.setPerson(person);
        userAccount.setRole(new AdminRole(Role.RoleType.Admin.getValue()));
        userAccount.setIsActive("Yes");        
        adminOrganization.getPersonDirectory().getPersonList().add(person);
        adminOrganization.getUserAccountDirectory().getUserAccountList().add(userAccount);
        
        
        
        SupplierOrganization supplierOrganization = new SupplierOrganization();
        business.getOrganizationDirectory().getOrganizationList().add(supplierOrganization);
        Supplier supplier = new Supplier();
        supplier.setSupplierName("HP");
        supplier.setFirstName("HP");
        supplier.setLastName("HP");
        supplier.setSupplierEnrolmentStatus("Enrolled");
        
        userAccount = new UserAccount();
        userAccount.setUserName("hp");
        userAccount.setPassword("hp");
        userAccount.setPerson(supplier);        
        userAccount.setRole(new SupplierRole(Role.RoleType.Supplier.getValue()));
        userAccount.setIsActive("Yes");
        
        supplierOrganization.getPersonDirectory().getPersonList().add(supplier);
        supplierOrganization.getUserAccountDirectory().getUserAccountList().add(userAccount);
        
        ProductDirectory productList = supplier.getProductDirectory();
        productList.createProduct("X2", 750.0, 100);
        productList.createProduct("X3", 550.0, 100);
            
        CustomerOrganization customerOrganization = new CustomerOrganization();
        business.getOrganizationDirectory().getOrganizationList().add(customerOrganization);
        Customer customer = new Customer(); 
        customer.setCustomerName("Gowtham");
        customer.setCustomerAddress("Boston");
        customer.setPhone(123);
        customer.setFirstName("Gowtham");
        customer.setLastName("S");
        userAccount = new UserAccount();
        userAccount.setUserName("gowtham");
        userAccount.setPassword("gowtham");
        userAccount.setPerson(customer);
        userAccount.setRole(new CustomerRole(Role.RoleType.Customer.getValue()));
        //userAccount.setIsActive("Yes");
        customerOrganization.getPersonDirectory().getPersonList().add(customer);
        customerOrganization.getUserAccountDirectory().getUserAccountList().add(userAccount);
        
        SalesOrganization salesOrganization = new SalesOrganization();
        business.getOrganizationDirectory().getOrganizationList().add(salesOrganization);
        Person salesSpecialist = new Person();
        salesSpecialist.setFirstName("sales");
        salesSpecialist.setLastName("sales");
        
        userAccount = new UserAccount();
        userAccount.setUserName("sales");
        userAccount.setPassword("sales");
        userAccount.setPerson(salesSpecialist);        
        userAccount.setRole(new SalesRole(Role.RoleType.Sales.getValue()));
        userAccount.setIsActive("Yes");
        
        salesOrganization.getPersonDirectory().getPersonList().add(salesSpecialist);
        salesOrganization.getUserAccountDirectory().getUserAccountList().add(userAccount);
        
        ShippingOrganization shippingOrganization = new ShippingOrganization();
        business.getOrganizationDirectory().getOrganizationList().add(shippingOrganization);
        Person shippingSpecialist = new Person();
        shippingSpecialist.setFirstName("shipping");
        shippingSpecialist.setLastName("shipping");
        
        userAccount = new UserAccount();
        userAccount.setUserName("shipping");
        userAccount.setPassword("shipping");
        userAccount.setPerson(shippingSpecialist);        
        userAccount.setRole(new ShippingRole(Role.RoleType.Shipping.getValue()));
        userAccount.setIsActive("Yes");
        
        shippingOrganization.getPersonDirectory().getPersonList().add(shippingSpecialist);
        shippingOrganization.getUserAccountDirectory().getUserAccountList().add(userAccount);
        
        return business;
    }
}
