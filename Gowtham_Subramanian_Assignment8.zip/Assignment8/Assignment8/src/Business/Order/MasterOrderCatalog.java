/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Order;

import java.util.ArrayList;

/**
 *
 * @author Gowtham
 */
public class MasterOrderCatalog {

    private ArrayList<Order> orders;
    public MasterOrderCatalog()
    {
        orders = new ArrayList<Order>();
    }
    public ArrayList<Order> getOrders() {
        return orders;
    }
    
    public Order addOrder(Order order)
    {
        orders.add(order);
        return order;
    }
}
