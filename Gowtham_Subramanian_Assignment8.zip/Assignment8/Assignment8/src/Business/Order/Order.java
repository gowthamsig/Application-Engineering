/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Order;
import Business.Product.Product;
import java.util.ArrayList;

/**
 *
 * @author Gowtham
 */
public class Order {

    private ArrayList<OrderItem> orderItems;
    private int orderNumber;
    private static int count = 1;
    
    public Order()
    {
        orderNumber = count++;
        orderItems = new ArrayList<OrderItem>();
    }
    
    public ArrayList<OrderItem> getOrderItems() {
        return orderItems;
    }   

    public int getOrderNumber() {
        return orderNumber;
    }

    public void removeOrderItem(OrderItem item)
    {
        orderItems.remove(item);
    }
    
    public OrderItem addOrderItem(Product product, int quantity)
    {
        OrderItem oi = new OrderItem();
        oi.setProductItem(product);
        oi.setQuantity(quantity);
        orderItems.add(oi);
        return oi;
    }
    
    @Override
    public String toString(){
        return String.valueOf(this.orderNumber);
    }
}
