/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Role;

import Business.Business.Business;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import UserInterface.ShippingRole.ShippingWorkAreaJPanel;
import javax.swing.JPanel;

/**
 *
 * @author Gowtham
 */
public class ShippingRole extends Role{
    public ShippingRole(String name) {
        super(RoleType.Shipping.getValue());
    }

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount userAccount, Organization organization, Business business) {
        return new ShippingWorkAreaJPanel(userProcessContainer,userAccount,organization, business);
    }
}
