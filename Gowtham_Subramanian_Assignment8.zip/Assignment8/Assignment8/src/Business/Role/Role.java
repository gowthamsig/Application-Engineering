/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Role;

import Business.Business.Business;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import javax.swing.JPanel;

/**
 *
 * @author Gowtham
 */
public abstract class Role {
    
    private String name;  
    
    public enum RoleType{
        Admin("Admin")
        ,Customer("Customer")
        ,Supplier("Supplier")
        ,Shipping("Shipping")
        ,Sales("Sales");
        
        private String value;
        
        private RoleType(String value) {
            this.value = value;
        }
        
        public String getValue(){
            return value;
        }
        
        @Override
        public String toString(){
            return value;
        }
    }
    
    public Role(String name) {
        this.name = name;        
    
    }  
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public abstract JPanel createWorkArea(JPanel userProcessContainer, UserAccount userAccount, Organization organization, Business business);
    @Override
    public String toString()
    {
        return this.getClass().getSimpleName();
    }
}
