/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Role;

import Business.Business.Business;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import UserInterface.SalesRole.SalesWorkAreaJPanel;
import javax.swing.JPanel;

/**
 *
 * @author Gowtham
 */
public class SalesRole extends Role{
    public SalesRole(String name) {
        super(Role.RoleType.Sales.getValue());
    }

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount userAccount, Organization organization, Business business) {
        return new SalesWorkAreaJPanel(userProcessContainer,userAccount,organization, business);
    }
}
