/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Role;

import Business.Business.Business;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import UserInterface.CustomerRole.CutomerWorkAreaJPanel;
import javax.swing.JPanel;

/**
 *
 * @author Gowtham
 */
public class CustomerRole extends Role{

    public CustomerRole(String name) {
        super(RoleType.Customer.getValue());
    }

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount userAccount, Organization organization, Business business) {
        return new CutomerWorkAreaJPanel(userProcessContainer,userAccount,organization, business);
    }
    
}
