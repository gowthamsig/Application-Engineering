/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Person;

import Business.Order.MasterOrderCatalog;

/**
 *
 * @author Gowtham
 */
public class Customer extends Person{

    private String customerName;
    private String customerAddress;
    private long phone;
    private MasterOrderCatalog moc;

    /**
     * @return the customerName
     */

    public Customer() {
        this.moc = new MasterOrderCatalog();
    }

    public String getCustomerName() {
        return customerName;
    }

    /**
     * @param customerName the customerName to set
     */
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    /**
     * @return the customerAddress
     */
    public String getCustomerAddress() {
        return customerAddress;
    }

    /**
     * @param customerAddress the customerAddress to set
     */
    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }

    /**
     * @return the phone
     */
    public long getPhone() {
        return phone;
    }

    /**
     * @param phone the phone to set
     */
    public void setPhone(long phone) {
        this.phone = phone;
    }

    /**
     * @return the moc
     */
    public MasterOrderCatalog getMoc() {
        return moc;
    }

    /**
     * @param moc the moc to set
     */
    public void setMoc(MasterOrderCatalog moc) {
        this.moc = moc;
    }

    @Override
    public String toString() {
        return this.getCustomerName();
    }

}
