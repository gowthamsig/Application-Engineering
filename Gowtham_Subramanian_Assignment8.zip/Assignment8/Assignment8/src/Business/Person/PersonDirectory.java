/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Person;

import java.util.ArrayList;

/**
 *
 * @author Gowtham
 */
public class PersonDirectory {
    private ArrayList<Person> personList;
    
    public PersonDirectory() {
        personList = new ArrayList<Person>();
    }

    public ArrayList<Person> getPersonList() {
        return personList;
    }

    public void setPersonList(ArrayList<Person> personList) {
        this.personList = personList;
    }
    
    public Supplier createAdmin(String supplierName) {
        Supplier supplierDetails = new Supplier();
        supplierDetails.setSupplierName(supplierName);
        //supplierDetails.setType(UserAccount.ADMIN_ROLE);
        personList.add(supplierDetails);
        return supplierDetails;
    }
    
    public Supplier createSupplier(String supplierName) {
        Supplier supplierDetails = new Supplier();
        supplierDetails.setSupplierName(supplierName);
        //supplierDetails.setType(UserAccount.SUPPLIER_ROLE);
        personList.add(supplierDetails);
        return supplierDetails;
    }
    
    public Person createSalesSpecialist(String firstName, String lastName) {
        Person personDetails = new Person();
        personDetails.setFirstName(firstName);
        personDetails.setLastName(lastName);
        //supplierDetails.setType(UserAccount.SUPPLIER_ROLE);
        personList.add(personDetails);
        return personDetails;
    }
    
    public Person createShippingSpecialist(String firstName, String lastName) {
        Person personDetails = new Person();
        personDetails.setFirstName(firstName);
        personDetails.setLastName(lastName);
        //supplierDetails.setType(UserAccount.SUPPLIER_ROLE);
        personList.add(personDetails);
        return personDetails;
    }
    
    public Customer addCustomer(String customerName, String address, long phone)
    {
        Customer customer = new Customer();
        customer.setCustomerName(customerName);
        customer.setFirstName(customerName);
        customer.setCustomerAddress(address);
        customer.setPhone(phone);
        //customer.setType(UserAccount.CUSTOMER_ROLE);
        personList.add(customer);        
        return customer;
    }
    

    public void deletePerson(Person personDetails) {
        personList.remove(personDetails);
    }
    
}
