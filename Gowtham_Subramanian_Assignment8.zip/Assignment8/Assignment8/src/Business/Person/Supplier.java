/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Person;

import Business.Product.ProductDirectory;

/**
 *
 * @author Gowtham
 */
public class Supplier extends Person {

    private String supplierName;
    private String supplierEnrolmentStatus;
    private ProductDirectory productDirectory;

    public Supplier() {
        productDirectory = new ProductDirectory();
        supplierEnrolmentStatus = "Not Enrolled";
    }

    /**
     * @return the supplierName
     */
    public String getSupplierName() {
        return supplierName;
    }

    /**
     * @param supplierName the supplierName to set
     */
    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    /**
     * @return the productDirectory
     */
    public ProductDirectory getProductDirectory() {
        return productDirectory;
    }

    /**
     * @param productDirectory the productDirectory to set
     */
    public void setProductDirectory(ProductDirectory productDirectory) {
        this.productDirectory = productDirectory;
    }
    
    @Override
    public String toString()
    {
        return this.getSupplierName();
    }

    /**
     * @return the supplierEnrolmentStatus
     */
    public String getSupplierEnrolmentStatus() {
        return supplierEnrolmentStatus;
    }

    /**
     * @param supplierEnrolmentStatus the supplierEnrolmentStatus to set
     */
    public void setSupplierEnrolmentStatus(String supplierEnrolmentStatus) {
        this.supplierEnrolmentStatus = supplierEnrolmentStatus;
    }
            
}
