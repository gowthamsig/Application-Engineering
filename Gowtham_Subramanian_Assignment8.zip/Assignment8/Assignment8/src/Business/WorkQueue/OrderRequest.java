/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import Business.Order.Order;
import Business.UserAccount.UserAccount;

/**
 *
 * @author Gowtham
 */
public class OrderRequest extends WorkRequest{

    
    private Order order;
    private UserAccount shippingSpecialist;    
        
    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }
    
    public UserAccount getShippingSpecialist() {
        return shippingSpecialist;
    }

    public void setShippingSpecialist(UserAccount shippingSpecialist) {
        this.shippingSpecialist = shippingSpecialist;
    }

    
    
    
  
     @Override
    public String toString()
    {
        return this.getOrderType();
    }
    
}
