/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;
/**
 *
 * @author Gowtham
 */
public class EnrollmentRequest extends WorkRequest{
    
    private String enrolmentStatus;
    

    public String getEnrolmentStatus() {
        return enrolmentStatus;
    }

    public void setEnrolmentStatus(String message) {
        this.enrolmentStatus = message;
    }
    
    
    
    @Override
    public String toString()
    {
        return this.getOrderType();
    }
    
}
