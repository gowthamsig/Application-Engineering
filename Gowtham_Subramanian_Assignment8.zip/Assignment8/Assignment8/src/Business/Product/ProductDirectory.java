/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Product;

import java.util.ArrayList;

/**
 *
 * @author Gowtham
 */
public class ProductDirectory {

    private ArrayList<Product> productList;

    public ArrayList<Product> getProductList() {
        return productList;
    }

    public void setProductList(ArrayList<Product> productList) {
        this.productList = productList;
    }

    public ProductDirectory() {
        productList = new ArrayList<Product>();
    }

    public void createProduct(String productName, double productPrice, int availability) {
        Product product = new Product();
        product.setProductName(productName);
        product.setProductPrice(productPrice);
        product.setAvailability(availability);
        productList.add(product);
    }

    public void deleteProduct(Product productDetails) {
        productList.remove(productDetails);
    }

    public Product searchProduct(int id) {
        for(Product p: this.getProductList())
        {
            if(p.getProductID() == id)
            {
                return p;
            }
        }
        return null;
    }
}
