/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Product;

/**
 *
 * @author Gowtham
 */
public class Product implements Comparable {

    private String productName;
    private Double productPrice;
    private int productID;
    private int availability;
    private int sellCount = 0;
    private Double totalSalesAmount = 0.0;

    public int getAvailability() {
        return availability;
    }

    public void setAvailability(int availability) {
        this.availability = availability;
    }
    
    public static int count = 1;
    
    public Product()
    {
        productID = count++;
    }
    
    public String getProductName() {
        return productName;
        
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(Double productPrice) {
        this.productPrice = productPrice;
    }

    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }
    
    public void trackSales(int count, double salesPrice)
    {
        setSellCount(getSellCount() + count);
        setTotalSalesAmount((Double) (getTotalSalesAmount() + salesPrice));
    }
    
    @Override
    public String toString()
    {
        return this.productName;
    }
    
    /**
     * @return the sellCount
     */
    public int getSellCount() {
        return sellCount;
    }

    /**
     * @param sellCount the sellCount to set
     */
    public void setSellCount(int sellCount) {
        this.sellCount = sellCount;
    }

    /**
     * @return the totalSalesAmount
     */
    public Double getTotalSalesAmount() {
        return totalSalesAmount;
    }

    /**
     * @param totalSalesAmount the totalSalesAmount to set
     */
    public void setTotalSalesAmount(Double totalSalesAmount) {
        this.totalSalesAmount = totalSalesAmount;
    }

    public int compareTo(Object o) {
        int compareQuantity = ((Product)o).getSellCount();
        return compareQuantity - this.getSellCount();
    }
}
