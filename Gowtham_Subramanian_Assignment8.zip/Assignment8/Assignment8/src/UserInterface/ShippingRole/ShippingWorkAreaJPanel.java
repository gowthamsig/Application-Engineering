package UserInterface.ShippingRole;

import UserInterface.SalesRole.*;
import Business.Business.Business;
import Business.Person.Supplier;
import Business.UserAccount.UserAccount;
import Business.Organization.Organization;
import Business.Person.Person;
import java.awt.CardLayout;
import javax.swing.JPanel;

/**
 *
 * @author Mihir Mehta / Hechen Gao
 */
public class ShippingWorkAreaJPanel extends javax.swing.JPanel {
    private Person shippingSpecialist;
    private UserAccount userAccount;
    private Organization organization;
    private Business business;
    private JPanel userProcessContainer;
    
    public ShippingWorkAreaJPanel(JPanel userProcessContainer, UserAccount userAccount, Organization organization, Business business) {
        initComponents();
        this.shippingSpecialist = userAccount.getPerson();        
        this.userProcessContainer = userProcessContainer;
        this.userAccount = userAccount;
        this.business = business;
        this.organization = organization;
            }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        btnManageOrders = new javax.swing.JButton();

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("My Work Area ");

        btnManageOrders.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnManageOrders.setText("Manage Orders >>");
        btnManageOrders.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnManageOrdersActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(btnManageOrders, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(239, 239, 239))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(btnManageOrders)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnManageOrdersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnManageOrdersActionPerformed
        // TODO add your handling code here:
        ManageOrderRequestJPanel manageOrderRequest = new ManageOrderRequestJPanel(userProcessContainer, shippingSpecialist, organization, userAccount, business);
        userProcessContainer.add("ManageOrderRequest", manageOrderRequest);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.next(userProcessContainer); 
    }//GEN-LAST:event_btnManageOrdersActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnManageOrders;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
