package UserInterface.SupplierRole;

import Business.Product.Product;
import Business.Product.ProductDirectory;
import Business.Person.Supplier;
import java.awt.CardLayout;
import java.awt.Color;
import java.util.Collections;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.ValueMarker;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.TextAnchor;

/**
 *
 * @author Rushabh
 */
public class ManageProductCatalogJPanel extends javax.swing.JPanel {

    private Supplier supplier;
    private JPanel userProcessContainer;
    private ProductDirectory productList;

    /**
     * Creates new form ManageProductCatalogJPanel
     */
    public ManageProductCatalogJPanel(JPanel userProcessContainer, Supplier supplier) {
        initComponents();
        this.supplier = supplier;
        this.userProcessContainer = userProcessContainer;
        productList = supplier.getProductDirectory();

        identifyTopSellingProducts();
        populateTable();
        populateFields();

    }

    public void identifyTopSellingProducts() {
        int i = 0;
        lblTop1.setText("");
        lblTop3.setText("");
        Collections.sort(productList.getProductList());
        for (Product product : productList.getProductList()) {
            if (product.getSellCount() > 0) {
                if(i==0){
                    lblTop3.setText(product.getProductName());
                }
                if (!(lblTop1.getText().trim().equals(""))) {
                    lblTop1.setText(lblTop1.getText() + ", ");
                }
                lblTop1.setText(lblTop1.getText() + product.getProductName());
            }
            i++;
            if (i == 5) {
                break;
            }
        }
    }

    public void populateFields() {
        txtName.setText(supplier.getSupplierName());
    }

    public void populateTable() {
        try {
            DefaultTableModel dtm = (DefaultTableModel) productCatalogTable.getModel();
            dtm.setRowCount(0);
            for (Product product : productList.getProductList()) {
                Object row[] = new Object[6];
                row[0] = product;
                row[1] = product.getProductID();
                row[2] = product.getProductPrice();
                row[3] = product.getAvailability();
                row[4] = product.getSellCount();
                row[5] = product.getTotalSalesAmount();

                dtm.addRow(row);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Unable to display product details");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        productCatalogTable = new javax.swing.JTable();
        btnCreate = new javax.swing.JButton();
        btnCost = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        lblTop = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        btnRefresh = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnView1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        lblTop1 = new javax.swing.JLabel();
        btnSearch1 = new javax.swing.JButton();
        btnQuantity1 = new javax.swing.JButton();
        lblTop2 = new javax.swing.JLabel();
        lblTop3 = new javax.swing.JLabel();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("Manage Product Catalog");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        productCatalogTable.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        productCatalogTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Product Name", "Product ID", "Price", "Availability", "#  Sold", "Sales Amount"
            }
        ));
        jScrollPane1.setViewportView(productCatalogTable);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, 670, 170));

        btnCreate.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnCreate.setText("Create New Product >>");
        btnCreate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCreateActionPerformed(evt);
            }
        });
        add(btnCreate, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 340, -1, -1));

        btnCost.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnCost.setText("Cost Analysis");
        btnCost.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCostActionPerformed(evt);
            }
        });
        add(btnCost, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 310, 170, -1));

        btnBack.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnBack.setText("<< Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 380, 110, -1));

        lblTop.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblTop.setText("Top Selling Product:");
        add(lblTop, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 150, 170, -1));

        txtName.setEditable(false);
        txtName.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        txtName.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtName.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, new java.awt.Color(102, 102, 102), null, null));
        add(txtName, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 80, 150, 30));

        btnRefresh.setText("Refresh");
        btnRefresh.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnRefresh.setMargin(new java.awt.Insets(2, 1, 2, 1));
        btnRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefreshActionPerformed(evt);
            }
        });
        add(btnRefresh, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, 80, -1));

        btnDelete.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnDelete.setText("Delete Product(s)");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        add(btnDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 340, 190, -1));

        btnView1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnView1.setText("View Product Detail >>");
        btnView1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnView1ActionPerformed(evt);
            }
        });
        add(btnView1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 340, 220, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("Supplier:");
        add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 60, 170, -1));

        lblTop1.setText("Label 1");
        add(lblTop1, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 240, 160, 20));

        btnSearch1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnSearch1.setText("Search >>");
        btnSearch1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearch1ActionPerformed(evt);
            }
        });
        add(btnSearch1, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 110, 130, -1));

        btnQuantity1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnQuantity1.setText("Quantity Analysis");
        btnQuantity1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnQuantity1ActionPerformed(evt);
            }
        });
        add(btnQuantity1, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 270, 170, -1));

        lblTop2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblTop2.setText("Top (5) Selling Products:");
        add(lblTop2, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 210, 200, -1));

        lblTop3.setText("Label 1");
        add(lblTop3, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 170, 160, 30));
    }// </editor-fold>//GEN-END:initComponents

    private void btnCreateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCreateActionPerformed
        CreateNewProductJPanel createProduct = new CreateNewProductJPanel(userProcessContainer, productList, this);
        userProcessContainer.add("CreateProduct", createProduct);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.next(userProcessContainer);
    }//GEN-LAST:event_btnCreateActionPerformed

    private void btnCostActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCostActionPerformed
        DefaultCategoryDataset ds = new DefaultCategoryDataset();
        for (Product v : productList.getProductList()) {
            ds.setValue(new Double(v.getTotalSalesAmount()), "Sales Amount", v.getProductName().toString());
        }

        JFreeChart chart = ChartFactory.createBarChart("Sales Pattern - Amount", "Product Name", "Amount", ds, PlotOrientation.VERTICAL, false, true, false);
        CategoryPlot plot = (CategoryPlot) chart.getCategoryPlot();

        BarRenderer barRenderer = (BarRenderer) plot.getRenderer();
        barRenderer.setSeriesPaint(0, Color.GREEN);

        ChartFrame frame = new ChartFrame("Sales Pattern - Amount", chart);
        frame.setVisible(true);
        frame.setSize(450, 500);
    }//GEN-LAST:event_btnCostActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        userProcessContainer.remove(this);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshActionPerformed
        populateTable();
}//GEN-LAST:event_btnRefreshActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        try {
            int selectedRow = productCatalogTable.getSelectedRow();
            if (selectedRow >= 0) {
                int dialogResult = JOptionPane.showConfirmDialog(null, "Would you like to delete the selected product?", "Warning", JOptionPane.YES_NO_OPTION);
                if (dialogResult == JOptionPane.YES_OPTION) {

                    Product product = (Product) productCatalogTable.getValueAt(selectedRow, 0);
                    productList.deleteProduct(product);
                    populateTable();
                }
            } else {
                JOptionPane.showMessageDialog(null, "Please select a product from the table to delete.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Please select a product from the table to delete.");
        }
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnView1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnView1ActionPerformed
        // TODO add your handling code here:
        try {
            int selectedRow = productCatalogTable.getSelectedRow();
            if (selectedRow >= 0) {
                Product product = (Product) productCatalogTable.getValueAt(selectedRow, 0);
                ViewProductDetailJPanel viewProduct = new ViewProductDetailJPanel(userProcessContainer, product);
                userProcessContainer.add("ViewProduct", viewProduct);
                CardLayout layout = (CardLayout) userProcessContainer.getLayout();
                layout.next(userProcessContainer);
            } else {
                JOptionPane.showMessageDialog(null, "Please select a product from the table to view.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Please select a product from the table to view.");
        }
    }//GEN-LAST:event_btnView1ActionPerformed

    private void btnSearch1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearch1ActionPerformed
        // TODO add your handling code here:
        SearchForProductJPanel searchProduct = new SearchForProductJPanel(userProcessContainer, productList);
        userProcessContainer.add("SearchProduct", searchProduct);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.next(userProcessContainer);
    }//GEN-LAST:event_btnSearch1ActionPerformed

    private void btnQuantity1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnQuantity1ActionPerformed
        // TODO add your handling code here:
        DefaultCategoryDataset ds = new DefaultCategoryDataset();
        for (Product v : productList.getProductList()) {
            ds.setValue(new Integer(v.getSellCount()), "Sell Count", v.getProductName().toString());
        }

        JFreeChart chart = ChartFactory.createBarChart("Sales Pattern - Count", "Product Name", "Quantity", ds, PlotOrientation.VERTICAL, false, true, false);
        CategoryPlot plot = (CategoryPlot) chart.getCategoryPlot();

        BarRenderer barRenderer = (BarRenderer) plot.getRenderer();
        barRenderer.setSeriesPaint(0, Color.blue);

        ChartFrame frame = new ChartFrame("Sales Pattern - Count", chart);
        frame.setVisible(true);
        frame.setSize(450, 500);
    }//GEN-LAST:event_btnQuantity1ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnCost;
    private javax.swing.JButton btnCreate;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnQuantity1;
    private javax.swing.JButton btnRefresh;
    private javax.swing.JButton btnSearch1;
    private javax.swing.JButton btnView1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblTop;
    private javax.swing.JLabel lblTop1;
    private javax.swing.JLabel lblTop2;
    private javax.swing.JLabel lblTop3;
    private javax.swing.JTable productCatalogTable;
    private javax.swing.JTextField txtName;
    // End of variables declaration//GEN-END:variables
}
