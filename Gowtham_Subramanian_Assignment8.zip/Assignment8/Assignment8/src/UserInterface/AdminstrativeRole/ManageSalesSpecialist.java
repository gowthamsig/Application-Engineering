package UserInterface.AdminstrativeRole;

import Business.Business.Business;
import Business.Person.Person;
import Business.Person.PersonDirectory;
import Business.Organization.Organization;
import java.awt.CardLayout;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Mihir Mehta / Hechen Gao
 */
public class ManageSalesSpecialist extends javax.swing.JPanel {

    private PersonDirectory salesSpecialistDirectory;
    private Business business;
    private JPanel userProcessContainer;

    public ManageSalesSpecialist(JPanel userProcessContainer, Business business) {
        initComponents();
        this.userProcessContainer = userProcessContainer;
        this.business = business;

        populateTable();
    }

    public void populateTable() {
        try {
            DefaultTableModel dtm = (DefaultTableModel) salesSpecialistTable.getModel();
            dtm.setRowCount(0);
            for (Organization o : business.getOrganizationDirectory().getOrganizationList()) {
                if (o.getName().equalsIgnoreCase(Organization.Type.Sales.getValue())) {
                    salesSpecialistDirectory = o.getPersonDirectory();
                    for (Person salesSpecialist : salesSpecialistDirectory.getPersonList()) {

                        Object row[] = new Object[1];
                        row[0] = salesSpecialist;
                        dtm.addRow(row);

                    }
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Unable to display sales specialist details");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        salesSpecialistTable = new javax.swing.JTable();
        btnRefresh = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        btnRemove = new javax.swing.JButton();
        btnView = new javax.swing.JButton();
        btnAddSalesSpecialist = new javax.swing.JButton();

        salesSpecialistTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null},
                {null},
                {null},
                {null}
            },
            new String [] {
                "Sales Specialist Name"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(salesSpecialistTable);

        btnRefresh.setText("Refresh");
        btnRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefreshActionPerformed(evt);
            }
        });

        btnBack.setText("<<Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        btnRemove.setText("Remove");
        btnRemove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoveActionPerformed(evt);
            }
        });

        btnView.setText("View Sales Specialist");
        btnView.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewActionPerformed(evt);
            }
        });

        btnAddSalesSpecialist.setText("Add Sales Specialist");
        btnAddSalesSpecialist.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddSalesSpecialistActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnRefresh)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addComponent(btnBack)
                            .addGap(29, 29, 29)
                            .addComponent(btnRemove)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnView))
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 335, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnAddSalesSpecialist)))
                .addContainerGap(42, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(btnRefresh)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBack)
                    .addComponent(btnRemove)
                    .addComponent(btnView))
                .addGap(18, 18, 18)
                .addComponent(btnAddSalesSpecialist)
                .addContainerGap(83, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshActionPerformed
        populateTable();
    }//GEN-LAST:event_btnRefreshActionPerformed

    private void btnAddSalesSpecialistActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddSalesSpecialistActionPerformed
        AddSalesSpecialist addSalesSpecialist = new AddSalesSpecialist(userProcessContainer, salesSpecialistDirectory, this);
        userProcessContainer.add("AddSalesSpecialist", addSalesSpecialist);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.next(userProcessContainer);
    }//GEN-LAST:event_btnAddSalesSpecialistActionPerformed

    private void btnViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewActionPerformed
        try {
            int selectedRow = salesSpecialistTable.getSelectedRow();
            if (selectedRow >= 0) {
                Person salesSpecialist = (Person) salesSpecialistTable.getValueAt(selectedRow, 0);
                ViewSalesSpecialist viewSalesSpecialist = new ViewSalesSpecialist(userProcessContainer, salesSpecialist);
                userProcessContainer.add("ViewSalesSpecialist", viewSalesSpecialist);
                CardLayout layout = (CardLayout) userProcessContainer.getLayout();
                layout.next(userProcessContainer);
            } else {
                JOptionPane.showMessageDialog(null, "Please select a sales specialist from the table to view.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Please select a sales specialist from the table to view.");
        }
    }//GEN-LAST:event_btnViewActionPerformed

    private void btnRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoveActionPerformed
        try {
            int selectedRow = salesSpecialistTable.getSelectedRow();
            if (selectedRow >= 0) {
                int dialogResult = JOptionPane.showConfirmDialog(null, "Would you like to delete the selected sales specialist?", "Warning", JOptionPane.YES_NO_OPTION);
                if (dialogResult == JOptionPane.YES_OPTION) {

                    Person salesSpecialist = (Person) salesSpecialistTable.getValueAt(selectedRow, 0);
                    salesSpecialistDirectory.deletePerson(salesSpecialist);

                    populateTable();

                }
            } else {
                JOptionPane.showMessageDialog(null, "Please select a sales specilaist from the table to delete.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Please select a sales specialist from the table to delete.");
        }
    }//GEN-LAST:event_btnRemoveActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        userProcessContainer.remove(this);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
    }//GEN-LAST:event_btnBackActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddSalesSpecialist;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnRefresh;
    private javax.swing.JButton btnRemove;
    private javax.swing.JButton btnView;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable salesSpecialistTable;
    // End of variables declaration//GEN-END:variables

}
