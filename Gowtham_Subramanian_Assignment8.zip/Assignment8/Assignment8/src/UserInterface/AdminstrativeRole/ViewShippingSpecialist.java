package UserInterface.AdminstrativeRole;

import Business.Person.Person;
import Business.Product.ProductDirectory;
import java.awt.CardLayout;
import javax.swing.JPanel;


/**
 *
 * @author Mihir Mehta / Hechen Gao
 */
public class ViewShippingSpecialist extends javax.swing.JPanel {

    private Person shippingSpecialist;
    private JPanel userProcessContainer;
    
    
    public ViewShippingSpecialist(JPanel userProcessContainer, Person shippingSpecialist) {
        initComponents();
        this.userProcessContainer = userProcessContainer;
        this.shippingSpecialist = shippingSpecialist;
        
        
        populateFields();
    }

    public void populateFields()
    {
        shippingSpecialistName.setText(shippingSpecialist.getFirstName() + " " + shippingSpecialist.getLastName());
    }
    
       
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        shippingSpecialistName = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        shippingSpecialistName1 = new javax.swing.JLabel();

        shippingSpecialistName.setText("jLabel1");

        btnBack.setText("<< Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        shippingSpecialistName1.setText("Shipping Specialist:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnBack)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(shippingSpecialistName1)
                        .addGap(18, 18, 18)
                        .addComponent(shippingSpecialistName)))
                .addContainerGap(247, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(shippingSpecialistName)
                    .addComponent(shippingSpecialistName1))
                .addGap(44, 44, 44)
                .addComponent(btnBack)
                .addContainerGap(229, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
    userProcessContainer.remove(this);
    CardLayout layout = (CardLayout) userProcessContainer.getLayout();
    layout.previous(userProcessContainer);
    }//GEN-LAST:event_btnBackActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JLabel shippingSpecialistName;
    private javax.swing.JLabel shippingSpecialistName1;
    // End of variables declaration//GEN-END:variables
}
