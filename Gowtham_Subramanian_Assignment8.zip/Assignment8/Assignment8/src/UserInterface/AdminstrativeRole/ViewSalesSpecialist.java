package UserInterface.AdminstrativeRole;

import Business.Person.Person;
import Business.Product.ProductDirectory;
import java.awt.CardLayout;
import javax.swing.JPanel;


/**
 *
 * @author Mihir Mehta / Hechen Gao
 */
public class ViewSalesSpecialist extends javax.swing.JPanel {

    private Person salesSpecialist;
    private JPanel userProcessContainer;
    
    
    public ViewSalesSpecialist(JPanel userProcessContainer, Person salesSpecialist) {
        initComponents();
        this.userProcessContainer = userProcessContainer;
        this.salesSpecialist = salesSpecialist;
        
        
        populateFields();
    }

    public void populateFields()
    {
        salesSpecialistName.setText(salesSpecialist.getFirstName() + " " + salesSpecialist.getLastName());
    }
    
       
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        salesSpecialistName = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        salesSpecialistName1 = new javax.swing.JLabel();

        salesSpecialistName.setText("jLabel1");

        btnBack.setText("<< Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        salesSpecialistName1.setText("Sales Specialist:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnBack)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(salesSpecialistName1)
                        .addGap(18, 18, 18)
                        .addComponent(salesSpecialistName)))
                .addContainerGap(262, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(salesSpecialistName)
                    .addComponent(salesSpecialistName1))
                .addGap(44, 44, 44)
                .addComponent(btnBack)
                .addContainerGap(229, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
    userProcessContainer.remove(this);
    CardLayout layout = (CardLayout) userProcessContainer.getLayout();
    layout.previous(userProcessContainer);
    }//GEN-LAST:event_btnBackActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JLabel salesSpecialistName;
    private javax.swing.JLabel salesSpecialistName1;
    // End of variables declaration//GEN-END:variables
}
