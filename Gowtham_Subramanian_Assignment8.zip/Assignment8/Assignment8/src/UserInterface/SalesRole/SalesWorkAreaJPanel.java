package UserInterface.SalesRole;

import Business.Business.Business;
import Business.Person.Supplier;
import Business.UserAccount.UserAccount;
import Business.Organization.Organization;
import Business.Person.Person;
import java.awt.CardLayout;
import javax.swing.JPanel;

/**
 *
 * @author Mihir Mehta / Hechen Gao
 */
public class SalesWorkAreaJPanel extends javax.swing.JPanel {
    private Person salesSpecialist;
    private UserAccount userAccount;
    private Organization organization;
    private Business business;
    private JPanel userProcessContainer;
    
    public SalesWorkAreaJPanel(JPanel userProcessContainer, UserAccount userAccount, Organization organization, Business business) {
        initComponents();
        this.salesSpecialist = userAccount.getPerson();        
        this.userProcessContainer = userProcessContainer;
        this.userAccount = userAccount;
        this.business = business;
        this.organization = organization;
            }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        btnManageER = new javax.swing.JButton();
        btnManageOrders = new javax.swing.JButton();

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("My Work Area ");

        btnManageER.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnManageER.setText("Manage Enrollment Requests >>");
        btnManageER.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnManageERActionPerformed(evt);
            }
        });

        btnManageOrders.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnManageOrders.setText("Manage Orders >>");
        btnManageOrders.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnManageOrdersActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(btnManageER)
                    .addComponent(btnManageOrders, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(236, 236, 236))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(28, 28, 28)
                .addComponent(btnManageER)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnManageOrders)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents
    private void btnManageERActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnManageERActionPerformed
            ManageEnrollmentRequestJPanel manageEnrollmentRequest = new ManageEnrollmentRequestJPanel(userProcessContainer, salesSpecialist, organization, userAccount);
            userProcessContainer.add("ManageEnrollmentRequest", manageEnrollmentRequest);
            CardLayout layout = (CardLayout) userProcessContainer.getLayout();
            layout.next(userProcessContainer);  
    }//GEN-LAST:event_btnManageERActionPerformed

    private void btnManageOrdersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnManageOrdersActionPerformed
        // TODO add your handling code here:
        ManageOrderRequestJPanel manageOrderRequest = new ManageOrderRequestJPanel(userProcessContainer, salesSpecialist, organization, userAccount, business);
        userProcessContainer.add("ManageOrderRequest", manageOrderRequest);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.next(userProcessContainer); 
    }//GEN-LAST:event_btnManageOrdersActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnManageER;
    private javax.swing.JButton btnManageOrders;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
