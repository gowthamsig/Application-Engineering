package UserInterface.SalesRole;

import Business.Organization.Organization;
import Business.Person.Person;
import Business.Person.Supplier;
import Business.UserAccount.UserAccount;
import Business.WorkQueue.EnrollmentRequest;
import Business.WorkQueue.OrderRequest;
import Business.WorkQueue.WorkRequest;
import java.awt.CardLayout;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author bala
 */
public class ManageEnrollmentRequestJPanel extends javax.swing.JPanel {

    private Person salesSpecialist;
    private UserAccount userAccount;
    private Organization organization;
    private JPanel userProcessContainer;
    

    /**
     * Creates new form ManageProductCatalogJPanel
     */
    public ManageEnrollmentRequestJPanel(JPanel userProcessContainer, Person salesSpecialist, Organization organization, UserAccount userAccount) {
        initComponents();
        this.salesSpecialist = this.salesSpecialist;
        this.organization = organization;
        this.userProcessContainer = userProcessContainer;
        this.userAccount = userAccount;
        
        cmbStatus.removeAllItems();
        cmbStatus.addItem("Enrollment Requested");
        cmbStatus.addItem("Enrollment Denied");
        cmbStatus.addItem("Enrolled");
        
        populateTable();
        

    }

    

   

    public void populateTable() {
        try {
            DefaultTableModel dtm = (DefaultTableModel) enrollmentRequestTable.getModel();
            dtm.setRowCount(0);
            for (WorkRequest workRequest : organization.getWorkQueue().getWorkRequestList()) {
                if (workRequest instanceof EnrollmentRequest) {
                if(((EnrollmentRequest)workRequest).getOrderType().equalsIgnoreCase("Supplier Enrollment Request") && ((EnrollmentRequest)workRequest).getEnrolmentStatus().equalsIgnoreCase(cmbStatus.getSelectedItem().toString())){
                Object row[] = new Object[4];
                row[0] = workRequest;
                row[1] = workRequest.getSender().getPerson();
                row[2] = workRequest.getReceiver() == null ? null : workRequest.getReceiver().getPerson();
                row[3] = ((EnrollmentRequest)workRequest).getEnrolmentStatus();
                dtm.addRow(row);
                }
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Unable to display enrollment requests");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        enrollmentRequestTable = new javax.swing.JTable();
        btnAssign = new javax.swing.JButton();
        btnReject = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        btnEnroll = new javax.swing.JButton();
        cmbStatus = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("Enrolment Requests");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        enrollmentRequestTable.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        enrollmentRequestTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Order Type", "Supplier", "Receiver", "Enrollment Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(enrollmentRequestTable);
        if (enrollmentRequestTable.getColumnModel().getColumnCount() > 0) {
            enrollmentRequestTable.getColumnModel().getColumn(3).setResizable(false);
        }

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, 850, 170));

        btnAssign.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnAssign.setText("Assign to me");
        btnAssign.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAssignActionPerformed(evt);
            }
        });
        add(btnAssign, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 330, 180, -1));

        btnReject.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnReject.setText("Reject");
        btnReject.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRejectActionPerformed(evt);
            }
        });
        add(btnReject, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 330, 170, -1));

        btnBack.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnBack.setText("<< Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 330, 110, -1));

        btnEnroll.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnEnroll.setText("Enroll");
        btnEnroll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnrollActionPerformed(evt);
            }
        });
        add(btnEnroll, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 330, 170, -1));

        cmbStatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbStatusActionPerformed(evt);
            }
        });
        add(cmbStatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 120, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("Enrollment Status");
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, -1, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void btnAssignActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAssignActionPerformed
        try {
            int selectedRow = enrollmentRequestTable.getSelectedRow();
            if (selectedRow >= 0) {
                    EnrollmentRequest request = (EnrollmentRequest) enrollmentRequestTable.getValueAt(selectedRow, 0);
                    request.setReceiver(userAccount);
                    populateTable();
                
            } else {
                JOptionPane.showMessageDialog(null, "Please select an entry from the table.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Please select an entry from the table.");
        }
    }//GEN-LAST:event_btnAssignActionPerformed

    private void btnRejectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRejectActionPerformed
        try {
            int selectedRow = enrollmentRequestTable.getSelectedRow();
            if (selectedRow >= 0) {
                    EnrollmentRequest request = (EnrollmentRequest) enrollmentRequestTable.getValueAt(selectedRow, 0);
                    request.setEnrolmentStatus("Enrollment Denied");
                    request.setReceiver(userAccount);
                    ((Supplier)request.getSender().getPerson()).setSupplierEnrolmentStatus("Enrollment Denied");                    
                    JOptionPane.showMessageDialog(null, "Enrollment Denied.");
                    populateTable();                    
                
            } else {
                JOptionPane.showMessageDialog(null, "Please select an entry from the table.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Please select an entry from the table.");
        }
    }//GEN-LAST:event_btnRejectActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        userProcessContainer.remove(this);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnEnrollActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnrollActionPerformed
        // TODO add your handling code here:
        try {
            int selectedRow = enrollmentRequestTable.getSelectedRow();
            if (selectedRow >= 0) {
                    EnrollmentRequest request = (EnrollmentRequest) enrollmentRequestTable.getValueAt(selectedRow, 0);
                    request.setEnrolmentStatus("Enrolled");
                    request.setReceiver(userAccount);
                    ((Supplier)request.getSender().getPerson()).setSupplierEnrolmentStatus("Enrolled");                    
                    JOptionPane.showMessageDialog(null, "Enrolled.");
                    populateTable();
            } else {
                JOptionPane.showMessageDialog(null, "Please select an entry from the table.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Please select an entry from the table.");
        }
    }//GEN-LAST:event_btnEnrollActionPerformed

    private void cmbStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbStatusActionPerformed
        // TODO add your handling code here:
        populateTable();
    }//GEN-LAST:event_cmbStatusActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAssign;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnEnroll;
    private javax.swing.JButton btnReject;
    private javax.swing.JComboBox cmbStatus;
    private javax.swing.JTable enrollmentRequestTable;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
