package UserInterface.CustomerRole;

import Business.Business.Business;
import Business.Order.Order;
import Business.Order.OrderItem;
import Business.Organization.Organization;
import Business.Person.Person;
import Business.UserAccount.UserAccount;
import Business.WorkQueue.OrderRequest;
import Business.WorkQueue.WorkRequest;
import java.awt.CardLayout;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author bala
 */
public class ManageOrdersJPanel extends javax.swing.JPanel {

    private Person customer;
    private UserAccount userAccount;
    private Organization organization;
    private Business business;
    private JPanel userProcessContainer;

    /**
     * Creates new form ManageProductCatalogJPanel
     */
    public ManageOrdersJPanel(JPanel userProcessContainer, Person customer, Organization organization, UserAccount userAccount, Business business) {
        initComponents();
        this.customer = this.customer;
        this.organization = organization;
        this.userProcessContainer = userProcessContainer;
        this.userAccount = userAccount;
        this.business = business;

        cmbStatus.removeAllItems();
        cmbStatus.addItem("Order Placed");
        cmbStatus.addItem("Pending Shipment");
        cmbStatus.addItem("Order Rejected");
        cmbStatus.addItem("Order Shipped");

        populateTable();

    }

    public void populateTable() {
        try {
            DefaultTableModel dtm = (DefaultTableModel) orderRequestTable.getModel();
            dtm.setRowCount(0);
            for (WorkRequest workRequest : userAccount.getWorkQueue().getWorkRequestList()) {

                if (((OrderRequest) workRequest).getStatus().equalsIgnoreCase(cmbStatus.getSelectedItem().toString())) {
                    Object row[] = new Object[3];
                    row[0] = workRequest;
                    row[1] = ((OrderRequest) workRequest).getOrder();

                    row[2] = ((OrderRequest) workRequest).getStatus();
                    dtm.addRow(row);
                }

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Unable to display order requests");
        }
    }

    public void populateOrderDetailsTable(Order order) {
        try {
            DefaultTableModel dtm = (DefaultTableModel) orderDetailsTable.getModel();
            dtm.setRowCount(0);
            for (OrderItem oi : order.getOrderItems()) {
                Object row[] = new Object[4];
                row[0] = oi;
                row[1] = oi.getProductItem().getProductPrice();
                row[2] = oi.getQuantity();
                row[3] = oi.getProductItem().getProductPrice() * oi.getQuantity();
                dtm.addRow(row);
            }
            lblOrderID.setText(String.valueOf(order.getOrderNumber()));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Unable to display order details");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        orderRequestTable = new javax.swing.JTable();
        btnBack = new javax.swing.JButton();
        cmbStatus = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        orderDetailsTable = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        btnViewOrderDetails = new javax.swing.JButton();
        lblOrderID = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("My Orders");

        orderRequestTable.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        orderRequestTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Message", "Order ID", "Order Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(orderRequestTable);

        btnBack.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnBack.setText("<< Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        cmbStatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbStatusActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("Order Status:");

        orderDetailsTable.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        orderDetailsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item Name", "Price", "Quantity", "Total Amount"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(orderDetailsTable);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("Order Details:");

        btnViewOrderDetails.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnViewOrderDetails.setText("View Order Details");
        btnViewOrderDetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewOrderDetailsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(cmbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 850, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 850, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblOrderID))
                    .addComponent(btnViewOrderDetails))
                .addGap(265, 265, 265))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cmbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnViewOrderDetails)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblOrderID, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnBack)
                .addGap(30, 30, 30))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void cmbStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbStatusActionPerformed
        // TODO add your handling code here:

        populateTable();
    }//GEN-LAST:event_cmbStatusActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        userProcessContainer.remove(this);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnViewOrderDetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewOrderDetailsActionPerformed
        // TODO add your handling code here:
        try {
            int selectedRow = orderRequestTable.getSelectedRow();
            if (selectedRow >= 0) {
                OrderRequest request = (OrderRequest) orderRequestTable.getValueAt(selectedRow, 0);
                Order order = request.getOrder();
                populateOrderDetailsTable(order);
            } else {
                JOptionPane.showMessageDialog(null, "Please select an entry from the table.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Please select an entry from the table.");
        }
    }//GEN-LAST:event_btnViewOrderDetailsActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnViewOrderDetails;
    private javax.swing.JComboBox cmbStatus;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblOrderID;
    private javax.swing.JTable orderDetailsTable;
    private javax.swing.JTable orderRequestTable;
    // End of variables declaration//GEN-END:variables
}
