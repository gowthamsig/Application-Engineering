/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import java.util.ArrayList;

/**
 *
 * @author Gowtham
 */
public class Order {
    
    private ArrayList<OrderItems> order;
    private static int count;
    private int orderId;
    private String purchaseDate;
    
    public Order(){
        
        count++;
        orderId=count;
        order = new ArrayList<OrderItems>();
    }

    public ArrayList<OrderItems> getOrder() {
        return order;
    }

    public void setOrder(ArrayList<OrderItems> order) {
        this.order = order;
    }

    public String getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(String purchaseDate) {
        this.purchaseDate = purchaseDate;
    }
     
    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }
    
    public OrderItems addOrderItem(){
        OrderItems oi= new OrderItems();
        order.add(oi);
        return oi;
    }
    
    public void removeOrderItem(OrderItems oi){
        order.remove(oi);
    }

    @Override
    public String toString() {
        return String.valueOf(this.orderId);
    }
    
    
}
