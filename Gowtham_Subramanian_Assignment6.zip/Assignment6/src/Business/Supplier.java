/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

/**
 *
 * @author Rushabh
 */
public class Supplier extends Person{
    
    
    private ProductCatalog productCatalog;

    public ProductCatalog getProductCatalog() {
        return productCatalog;
    }

    public void setProductCatalog(ProductCatalog productCatalog) {
        this.productCatalog = productCatalog;
    }
    public Supplier()
    {
        productCatalog = new ProductCatalog();
    }
        
    
    
}
