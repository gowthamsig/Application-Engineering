/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

/**
 *
 * @author Gowtham
 */
public class ConfigureBusiness {
    
    public static Business Initialize(){
        Business business = Business.getInstance();
        Admin admin = business.getAdmin();
        admin.setName("Gowtham");
        
        UserAccount u = business.getUserAccountDirectory().addUser();
        u.setPerson(admin);
        u.setRole(UserAccount.ADMIN);
        u.setStatus("Active");
        u.setUserName("admin");
        u.setPassword("admin");
        return business;
    }
    
}
