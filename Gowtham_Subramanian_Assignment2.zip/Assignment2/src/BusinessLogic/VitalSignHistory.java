/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package BusinessLogic;

import java.util.ArrayList;

/**
 *
 * @author Gowtham
 */
public class VitalSignHistory {
    
    private ArrayList<PatientVitalSign> vsd;
    //private Patient patient;
    
    public VitalSignHistory(){
        vsd = new ArrayList<>();
    }

  /*  public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    } */

    public ArrayList<PatientVitalSign> getVsd() {
        return vsd;
    }

    public void setVsd(ArrayList<PatientVitalSign> vsd) {
        this.vsd = vsd;
    }
      
    public PatientVitalSign addVitalSign(){
        PatientVitalSign vs = new PatientVitalSign();
        vsd.add(vs);
        return vs;
    }
    
     public void removeVitalSign(PatientVitalSign vs){
        vsd.remove(vs);
    }
}
