/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

/**
 *
 * @author Rushabh
 */
public class Product {
    private static int count = 0;
    private String prodName;
    private int price;
    private int modelNumber;
    private int availablity;
    private int salesCount;
    private int totalSalesPrice;
    
        public Product() {
        count++;
        modelNumber = count;
    }

    public int getSalesCount() {
        return salesCount;
    }

    public void setSalesCount(int salesCount) {
        this.salesCount = salesCount;
    }

    public int getTotalSalesPrice() {
        return totalSalesPrice;
    }

    public void setTotalSalesPrice(int totalSalesPrice) {
        this.totalSalesPrice = totalSalesPrice;
    }
        
        
    
    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getModelNumber() {
        return modelNumber;
    }

    public int getAvailablity() {
        return availablity;
    }

    public void setAvailablity(int availablity) {
        this.availablity = availablity;
    }
       
    @Override
    public String toString() {
        return prodName;
    }
    
}
