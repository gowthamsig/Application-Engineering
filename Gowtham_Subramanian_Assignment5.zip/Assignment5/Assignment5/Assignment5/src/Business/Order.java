/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import java.util.ArrayList;

/**
 *
 * @author Gowtham
 */
public class Order {
    
    private ArrayList<OrderItems> order;
    private static int count;
    private int orderId;
    
    public Order(){
        
        count++;
        orderId=count;
        order = new ArrayList<OrderItems>();
    }

    public ArrayList<OrderItems> getOrder() {
        return order;
    }

    public void setOrder(ArrayList<OrderItems> order) {
        this.order = order;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }
    
    public OrderItems addOrderItem(){
        OrderItems oi= new OrderItems();
        order.add(oi);
        return oi;
    }
    
    public void removeOrderItem(OrderItems oi){
        order.remove(oi);
    }
}
